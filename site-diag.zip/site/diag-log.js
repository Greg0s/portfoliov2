(function(){
  var box=document.createElement('div');
  box.style.cssText='position:fixed;left:0;top:0;right:0;z-index:2147483647;pointer-events:none;font:11px/1.25 monospace;color:#0f0;background:rgba(0,0,0,.75);white-space:pre;max-height:55vh;overflow:hidden;padding:2px';
  var lines=[];var t0=performance.now();
  function log(s){lines.push(((performance.now()-t0)|0)+' '+s);if(lines.length>34)lines.shift();box.textContent=lines.join('\n');}
  window.__diag=log;
  function d(e){var t=e.target;return (t&&t.tagName||'?')+(t&&t.className&&typeof t.className==='string'?'.'+t.className.split(' ')[0]:'');}
  ['touchstart','touchmove','touchend','touchcancel','pointerdown','pointerup','pointercancel','mousedown','mouseup','click','contextmenu','scroll'].forEach(function(n){
    var last=0;
    window.addEventListener(n,function(e){
      if(n==='touchmove'||n==='scroll'){var now=performance.now();if(now-last<80)return;last=now;}
      var xy=e.touches&&e.touches[0]?(' '+(e.touches[0].clientX|0)+','+(e.touches[0].clientY|0)):(e.clientX!==undefined?(' '+(e.clientX|0)+','+(e.clientY|0)):'');
      log(n+' '+d(e)+xy+' prev='+e.defaultPrevented+' canc='+e.cancelable+(n==='scroll'?' y='+(scrollY|0):''));
    },{capture:false,passive:true});
  });
  document.addEventListener('DOMContentLoaded',function(){document.body.appendChild(box);log('diag ready');});
})();
