import{Ln as e,Pt as t,c as n,s as r}from"./three.core.HpjG20kB.js";import{n as i,t as a}from"./journey.CmNyvey8.js";var o=`
  attribute float aNear;
  attribute float aSize;
  attribute float aAlpha;
  attribute float aBig;
  attribute vec2 aTwinkle;
  attribute float aKeep;
  attribute vec3 aColor;

  uniform float uTime;
  uniform float uDepth;
  uniform float uPerspective;
  uniform vec2 uViewport;
  uniform vec2 uVanish;
  uniform float uFarScale;
  uniform vec2 uFarShift;
  uniform float uFarOpacity;
  uniform float uFarFade;
  uniform float uNearOpacity;
  uniform float uPixelRatio;

  varying float vAlpha;
  varying float vCore;
  varying float vBig;
  varying vec3 vColor;

  float smoothstep01(float edge0, float edge1, float x) {
    float t = clamp((x - edge0) / (edge1 - edge0), 0.0, 1.0);
    return t * t * (3.0 - 2.0 * t);
  }

  void main() {
    float size = aSize;
    float alpha = aAlpha;
    if (aNear > 0.5) {
      // Near stars sit along the path, at their depth relative to the camera, in the swayed world.
      float relative = position.z - uDepth;
      vec4 mv = modelViewMatrix * vec4(position.x, position.y, relative * uPerspective, 1.0);
      gl_Position = projectionMatrix * mv;
      size *= uPerspective / max(1.0, -mv.z);
      bool shown = relative < 0.72 && relative > -2.8;
      alpha *= shown ? (1.0 - smoothstep01(0.45, 0.72, relative)) * (1.0 - smoothstep01(1.4, 2.8, -relative)) : 0.0;
      alpha *= uNearOpacity;
    } else {
      // Far stars barely move: a backdrop scaled toward the vanishing point, shifted by the mouse and the drift.
      vec2 screen = uVanish + position.xy * uFarScale + uFarShift;
      gl_Position = vec4(screen.x / uViewport.x * 2.0 - 1.0, 1.0 - screen.y / uViewport.y * 2.0, 0.0, 1.0);
      float phase = mod(uTime - aTwinkle.y, 2.0 * aTwinkle.x) / aTwinkle.x;
      float wave = 0.5 - 0.5 * cos(3.14159265 * phase);
      alpha *= mix(1.0, 0.2, wave) * uFarOpacity * (aKeep > 0.5 ? 1.0 : uFarFade);
    }
    vAlpha = alpha;
    vBig = aBig;
    vColor = aColor;
    // A big near star has a soft glow around it; every point gets a pixel of room for its antialiased edge.
    float drawn = aBig > 0.5 && aNear > 0.5 ? size * 5.0 : size + 2.0;
    vCore = size / drawn;
    gl_PointSize = drawn * uPixelRatio;
    if (alpha < 0.004) gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
  }
`,s=`
  varying float vAlpha;
  varying float vCore;
  varying float vBig;
  varying vec3 vColor;

  void main() {
    float d = length(gl_PointCoord - 0.5) * 2.0;
    float edge = fwidth(d);
    float core = 1.0 - smoothstep(vCore - edge, vCore + edge, d);
    float glow = vBig > 0.5 ? 0.35 * exp(-pow(max(0.0, d - vCore) / (vCore * 1.2), 2.0)) : 0.0;
    float a = vAlpha * max(core, glow);
    if (a < 0.002) discard;
    gl_FragColor = vec4(vColor * a, a);
  }
`;function c(c,l,u){let d=c.length,f=new Float32Array(d*3),p=new Float32Array(d),m=new Float32Array(d),h=new Float32Array(d),g=new Float32Array(d),_=new Float32Array(d*2),v=new Float32Array(d),y=new Float32Array(d*3).fill(1),b=(e,t)=>{let n=Math.sin(e*12.9898+t)*43758.5453;return n-Math.floor(n)};c.forEach((e,t)=>{b(t,1.7)<.36&&y.set(i([1,1,1],a(b(t,8.3)),.8),t*3),f.set(e.near?[e.x,-e.y,e.z]:[e.x,e.y,0],t*3),p[t]=+!!e.near,m[t]=e.size,h[t]=e.alpha,g[t]=+!!e.big,_.set([e.twinkleDuration||1,e.twinkleDelay],t*2),v[t]=+!!e.keep});let x=new n;x.setAttribute(`position`,new r(f,3)),x.setAttribute(`aNear`,new r(p,1)),x.setAttribute(`aSize`,new r(m,1)),x.setAttribute(`aAlpha`,new r(h,1)),x.setAttribute(`aBig`,new r(g,1)),x.setAttribute(`aTwinkle`,new r(_,2)),x.setAttribute(`aKeep`,new r(v,1)),x.setAttribute(`aColor`,new r(y,3));let S=new e({vertexShader:o,fragmentShader:s,transparent:!0,depthTest:!1,depthWrite:!1,blending:1,premultipliedAlpha:!0,uniforms:{uTime:{value:0},uDepth:{value:0},uPerspective:{value:l.perspective},uViewport:{value:[l.width,l.height]},uVanish:{value:[l.vpX,l.vpY]},uFarScale:{value:1},uFarShift:{value:[0,0]},uFarOpacity:{value:1},uFarFade:{value:1},uNearOpacity:{value:1},uPixelRatio:{value:u}}}),C=new t(x,S);C.frustumCulled=!1;let w=S.uniforms;return{points:C,resize(e,t){w.uPerspective&&(w.uPerspective.value=e.perspective),w.uViewport&&(w.uViewport.value=[e.width,e.height]),w.uVanish&&(w.uVanish.value=[e.vpX,e.vpY]),w.uPixelRatio&&(w.uPixelRatio.value=t)},update(e){let t=(e,t)=>{let n=w[e];n&&(n.value=t)};t(`uTime`,e.time),t(`uDepth`,e.depth),t(`uFarScale`,e.farScale),t(`uFarShift`,[e.farShiftX,e.farShiftY]),t(`uFarOpacity`,e.farOpacity),t(`uFarFade`,e.farFade),t(`uNearOpacity`,e.nearOpacity)},dispose(){x.dispose(),S.dispose()}}}export{c as createStars};